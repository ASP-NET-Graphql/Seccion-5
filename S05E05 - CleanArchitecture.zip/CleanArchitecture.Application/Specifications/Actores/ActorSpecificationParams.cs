﻿namespace CleanArchitecture.Application.Specifications.Actores
{
    public class ActorSpecificationParams : SpecificationParams
    {
    }
}
